/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../RADAV_APPLICATION/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[52];
    char stringdata0[918];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 15), // "latitudeChanged"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 16), // "longitudeChanged"
QT_MOC_LITERAL(4, 45, 11), // "zoomChanged"
QT_MOC_LITERAL(5, 57, 13), // "circleChanged"
QT_MOC_LITERAL(6, 71, 18), // "focusRocketChanged"
QT_MOC_LITERAL(7, 90, 17), // "rocketPathChanged"
QT_MOC_LITERAL(8, 108, 11), // "NoseAviByte"
QT_MOC_LITERAL(9, 120, 7), // "aboutQt"
QT_MOC_LITERAL(10, 128, 5), // "about"
QT_MOC_LITERAL(11, 134, 32), // "on_actionComm_Settings_triggered"
QT_MOC_LITERAL(12, 167, 23), // "on_actionQuit_triggered"
QT_MOC_LITERAL(13, 191, 27), // "on_actionAbout_QT_triggered"
QT_MOC_LITERAL(14, 219, 14), // "openSerialPort"
QT_MOC_LITERAL(15, 234, 15), // "closeSerialPort"
QT_MOC_LITERAL(16, 250, 8), // "readData"
QT_MOC_LITERAL(17, 259, 11), // "handleError"
QT_MOC_LITERAL(18, 271, 28), // "QSerialPort::SerialPortError"
QT_MOC_LITERAL(19, 300, 5), // "error"
QT_MOC_LITERAL(20, 306, 25), // "on_action_About_triggered"
QT_MOC_LITERAL(21, 332, 26), // "on_actionConnect_triggered"
QT_MOC_LITERAL(22, 359, 29), // "on_actionDisconnect_triggered"
QT_MOC_LITERAL(23, 389, 24), // "on_action_Open_triggered"
QT_MOC_LITERAL(24, 414, 25), // "on_mpuStartButton_clicked"
QT_MOC_LITERAL(25, 440, 20), // "on_sndtoGrph_clicked"
QT_MOC_LITERAL(26, 461, 23), // "on_action_New_triggered"
QT_MOC_LITERAL(27, 485, 21), // "on_start_stop_clicked"
QT_MOC_LITERAL(28, 507, 16), // "realtimeDataSlot"
QT_MOC_LITERAL(29, 524, 10), // "nav_update"
QT_MOC_LITERAL(30, 535, 26), // "on_includeHistoric_toggled"
QT_MOC_LITERAL(31, 562, 7), // "checked"
QT_MOC_LITERAL(32, 570, 16), // "updateDataFields"
QT_MOC_LITERAL(33, 587, 26), // "on_zoomSlider_valueChanged"
QT_MOC_LITERAL(34, 614, 5), // "value"
QT_MOC_LITERAL(35, 620, 31), // "on_latitudeSpinBox_valueChanged"
QT_MOC_LITERAL(36, 652, 4), // "arg1"
QT_MOC_LITERAL(37, 657, 32), // "on_longitudeSpinBox_valueChanged"
QT_MOC_LITERAL(38, 690, 25), // "on_circleCheckBox_clicked"
QT_MOC_LITERAL(39, 716, 30), // "on_focusRocketCheckBox_clicked"
QT_MOC_LITERAL(40, 747, 15), // "convertGPSCoord"
QT_MOC_LITERAL(41, 763, 7), // "degrees"
QT_MOC_LITERAL(42, 771, 7), // "minutes"
QT_MOC_LITERAL(43, 779, 16), // "updateRocketPath"
QT_MOC_LITERAL(44, 796, 10), // "randomPath"
QT_MOC_LITERAL(45, 807, 8), // "get_zoom"
QT_MOC_LITERAL(46, 816, 7), // "get_lat"
QT_MOC_LITERAL(47, 824, 8), // "get_long"
QT_MOC_LITERAL(48, 833, 15), // "get_circleState"
QT_MOC_LITERAL(49, 849, 20), // "get_focusRocketState"
QT_MOC_LITERAL(50, 870, 14), // "get_rocketPath"
QT_MOC_LITERAL(51, 885, 32) // "QList<MainWindow::GPSCoordinate>"

    },
    "MainWindow\0latitudeChanged\0\0"
    "longitudeChanged\0zoomChanged\0circleChanged\0"
    "focusRocketChanged\0rocketPathChanged\0"
    "NoseAviByte\0aboutQt\0about\0"
    "on_actionComm_Settings_triggered\0"
    "on_actionQuit_triggered\0"
    "on_actionAbout_QT_triggered\0openSerialPort\0"
    "closeSerialPort\0readData\0handleError\0"
    "QSerialPort::SerialPortError\0error\0"
    "on_action_About_triggered\0"
    "on_actionConnect_triggered\0"
    "on_actionDisconnect_triggered\0"
    "on_action_Open_triggered\0"
    "on_mpuStartButton_clicked\0"
    "on_sndtoGrph_clicked\0on_action_New_triggered\0"
    "on_start_stop_clicked\0realtimeDataSlot\0"
    "nav_update\0on_includeHistoric_toggled\0"
    "checked\0updateDataFields\0"
    "on_zoomSlider_valueChanged\0value\0"
    "on_latitudeSpinBox_valueChanged\0arg1\0"
    "on_longitudeSpinBox_valueChanged\0"
    "on_circleCheckBox_clicked\0"
    "on_focusRocketCheckBox_clicked\0"
    "convertGPSCoord\0degrees\0minutes\0"
    "updateRocketPath\0randomPath\0get_zoom\0"
    "get_lat\0get_long\0get_circleState\0"
    "get_focusRocketState\0get_rocketPath\0"
    "QList<MainWindow::GPSCoordinate>"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      42,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  224,    2, 0x06 /* Public */,
       3,    0,  225,    2, 0x06 /* Public */,
       4,    0,  226,    2, 0x06 /* Public */,
       5,    0,  227,    2, 0x06 /* Public */,
       6,    0,  228,    2, 0x06 /* Public */,
       7,    0,  229,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  230,    2, 0x08 /* Private */,
       9,    0,  231,    2, 0x08 /* Private */,
      10,    0,  232,    2, 0x08 /* Private */,
      11,    0,  233,    2, 0x08 /* Private */,
      12,    0,  234,    2, 0x08 /* Private */,
      13,    0,  235,    2, 0x08 /* Private */,
      14,    0,  236,    2, 0x08 /* Private */,
      15,    0,  237,    2, 0x08 /* Private */,
      16,    0,  238,    2, 0x08 /* Private */,
      17,    1,  239,    2, 0x08 /* Private */,
      20,    0,  242,    2, 0x08 /* Private */,
      21,    0,  243,    2, 0x08 /* Private */,
      22,    0,  244,    2, 0x08 /* Private */,
      23,    0,  245,    2, 0x08 /* Private */,
      24,    0,  246,    2, 0x08 /* Private */,
      25,    0,  247,    2, 0x08 /* Private */,
      26,    0,  248,    2, 0x08 /* Private */,
      27,    0,  249,    2, 0x08 /* Private */,
      28,    0,  250,    2, 0x08 /* Private */,
      29,    0,  251,    2, 0x08 /* Private */,
      30,    1,  252,    2, 0x08 /* Private */,
      32,    0,  255,    2, 0x08 /* Private */,
      33,    1,  256,    2, 0x0a /* Public */,
      35,    1,  259,    2, 0x0a /* Public */,
      37,    1,  262,    2, 0x0a /* Public */,
      38,    1,  265,    2, 0x0a /* Public */,
      39,    1,  268,    2, 0x0a /* Public */,
      40,    2,  271,    2, 0x0a /* Public */,
      43,    0,  276,    2, 0x0a /* Public */,
      44,    0,  277,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
      45,    0,  278,    2, 0x02 /* Public */,
      46,    0,  279,    2, 0x02 /* Public */,
      47,    0,  280,    2, 0x02 /* Public */,
      48,    0,  281,    2, 0x02 /* Public */,
      49,    0,  282,    2, 0x02 /* Public */,
      50,    0,  283,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   34,
    QMetaType::Void, QMetaType::Double,   36,
    QMetaType::Void, QMetaType::Double,   36,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Double, QMetaType::Double, QMetaType::Double,   41,   42,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Double,
    QMetaType::Double,
    QMetaType::Double,
    QMetaType::Bool,
    QMetaType::Bool,
    0x80000000 | 51,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->latitudeChanged(); break;
        case 1: _t->longitudeChanged(); break;
        case 2: _t->zoomChanged(); break;
        case 3: _t->circleChanged(); break;
        case 4: _t->focusRocketChanged(); break;
        case 5: _t->rocketPathChanged(); break;
        case 6: _t->NoseAviByte(); break;
        case 7: _t->aboutQt(); break;
        case 8: _t->about(); break;
        case 9: _t->on_actionComm_Settings_triggered(); break;
        case 10: _t->on_actionQuit_triggered(); break;
        case 11: _t->on_actionAbout_QT_triggered(); break;
        case 12: _t->openSerialPort(); break;
        case 13: _t->closeSerialPort(); break;
        case 14: _t->readData(); break;
        case 15: _t->handleError((*reinterpret_cast< QSerialPort::SerialPortError(*)>(_a[1]))); break;
        case 16: _t->on_action_About_triggered(); break;
        case 17: _t->on_actionConnect_triggered(); break;
        case 18: _t->on_actionDisconnect_triggered(); break;
        case 19: _t->on_action_Open_triggered(); break;
        case 20: _t->on_mpuStartButton_clicked(); break;
        case 21: _t->on_sndtoGrph_clicked(); break;
        case 22: _t->on_action_New_triggered(); break;
        case 23: _t->on_start_stop_clicked(); break;
        case 24: _t->realtimeDataSlot(); break;
        case 25: _t->nav_update(); break;
        case 26: _t->on_includeHistoric_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->updateDataFields(); break;
        case 28: _t->on_zoomSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->on_latitudeSpinBox_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 30: _t->on_longitudeSpinBox_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 31: _t->on_circleCheckBox_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->on_focusRocketCheckBox_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: { double _r = _t->convertGPSCoord((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 34: _t->updateRocketPath(); break;
        case 35: _t->randomPath(); break;
        case 36: { double _r = _t->get_zoom();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 37: { double _r = _t->get_lat();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 38: { double _r = _t->get_long();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 39: { bool _r = _t->get_circleState();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 40: { bool _r = _t->get_focusRocketState();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 41: { QList<MainWindow::GPSCoordinate> _r = _t->get_rocketPath();
            if (_a[0]) *reinterpret_cast< QList<MainWindow::GPSCoordinate>*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::latitudeChanged)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::longitudeChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::zoomChanged)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::circleChanged)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::focusRocketChanged)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (MainWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MainWindow::rocketPathChanged)) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 42)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 42;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 42)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 42;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::latitudeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void MainWindow::longitudeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void MainWindow::zoomChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void MainWindow::circleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void MainWindow::focusRocketChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}

// SIGNAL 5
void MainWindow::rocketPathChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
