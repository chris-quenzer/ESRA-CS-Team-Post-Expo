This folder contains the RADAV application installer. This application is designed for use on the Oregon State Rocketry ESRA Rocket 2016-2017. This is the installer for addign it to any computer running windows 7-10 with the proper deivers to interface with a serial connected radio r device. 

Use:
1. Download
2. Run the installer
3. Navigate to eh install directory, and launch the application called TestApplication.exe

Removal:
1. Go to install directory
2. Run maintenancetool.exe
3. Select uninstall
